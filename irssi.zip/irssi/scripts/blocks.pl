#!/usr/bin/perl
use strict;
use Irssi;
use vars qw($VERSION %IRSSI);

my $VERSION = '2 :0';
%IRSSI = (
  authors     => 'Meepsheep',
  contact     => 'irc.maract.us #dongforce',
  name        => 'blocks',
  description => 'penis pumps',
  license     => 'cocks',
);


sub blocks {
my ($data,$server,$witem) = @_;
my $shit = $data;
my $lotsamount = 50;

if ($shit =~ /-help/i) {
print CRAP "USAGE:";
print CRAP "/blocks";
print CRAP "-gay";
print CRAP "-rasta";
print CRAP "-usa";
print CRAP "-heil";
print CRAP "-random";
print CRAP "-lots";
}

unless ($shit =~ /^-/i) {
Irssi::Windowitem::command($witem,"say \003".int(rand(16)).",".int(rand(16))."   $shit   ");
}

if ($shit =~ /-gay/i) {
$shit =~ s/-gay //i;
Irssi::Windowitem::command($witem,"say \0030,5   $shit   ");
Irssi::Windowitem::command($witem,"say \0030,7   $shit   ");
Irssi::Windowitem::command($witem,"say \0030,8   $shit   ");
Irssi::Windowitem::command($witem,"say \0030,3   $shit   ");
Irssi::Windowitem::command($witem,"say \0030,2   $shit   ");
Irssi::Windowitem::command($witem,"say \0030,6   $shit   ");
}

if ($shit =~ /-rasta/i) {
$shit =~ s/-rasta //i;
Irssi::Windowitem::command($witem,"say \0030,9   $shit   ");
Irssi::Windowitem::command($witem,"say \0030,8   $shit   ");
Irssi::Windowitem::command($witem,"say \0030,5   $shit   ");
}

if ($shit =~ /-usa/i) {
$shit =~ s/-usa //i;
Irssi::Windowitem::command($witem,"say \003,2       \0031,0 $shit       ");
Irssi::Windowitem::command($witem,"say \003,2       \0031,5 $shit       ");
Irssi::Windowitem::command($witem,"say \0031,0        $shit       ");
Irssi::Windowitem::command($witem,"say \0031,5        $shit       ");
Irssi::Windowitem::command($witem,"say \0031,0        $shit       ");
}

if ($shit =~ /-heil/i) {
$shit =~ s/-heil //i;
Irssi::Windowitem::command($witem,"say \0034,1   $shit   ");
Irssi::Windowitem::command($witem,"say \0038,4   $shit   ");
Irssi::Windowitem::command($witem,"say \0031,8   $shit   ");
}

if ($shit =~ /-random/i) {
$shit =~ s/-random //i;
for (my $nigs=1; $nigs<7; $nigs++) {
Irssi::Windowitem::command($witem,"say \003".int(rand(16)).",".int(rand(16))."   $shit   ");
} }

if ($shit =~ /-lots/i) {
$shit =~ s/-lots //i;
for (my $nigs=1; $nigs<$lotsamount+1; $nigs++) {
Irssi::Windowitem::command($witem,"say \003".int(rand(16)).",".int(rand(16))."   $shit   ");
} }

}

Irssi::command_bind('blocks', 'blocks');