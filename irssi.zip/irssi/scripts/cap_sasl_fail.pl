use strict;
use warnings;

our $VERSION = '2.1'; # bb62357c61d9e54
our %IRSSI = (
    authors     => 'Nei',
    name        => 'cap_sasl_fail',
    description => 'Disconnect from server if SASL authentication fails.',
    license     => 'GNU GPLv2 or later',
   );

use Irssi 20150920;
use version;

my %disconnect_next;

my $irssi_version = qv(Irssi::parse_special('v$J') =~ s/-.*//r);
die sprintf "Please use /set sasl_disconnect_on_failure instead of this script.\n"
    if $irssi_version >= v1.0.0;

Irssi::signal_register({'server sasl fail' => [qw[iobject string]]});
Irssi::signal_add_first('server sasl fail' => 'sasl_fail_failed');
Irssi::signal_add_first('server sasl failure' => 'sasl_failure');
Irssi::signal_add_first('server cap end' => 'server_cap_end' );

sub sasl_fail_failed {
    Irssi::signal_emit('server sasl failure', @_);
}

sub sasl_failure {
    my ($server, $reason) = @_;
    &Irssi::signal_continue;
    my $disconnect = Irssi::settings_get_bool('sasl_disconnect_on_fail');
    my $reconnect = Irssi::settings_get_bool('sasl_reconnect_on_fail');
    if ($disconnect || $reconnect) {
	$server->send_raw_now('QUIT');
    }
    unless ($reason =~ /timed out/ || $reconnect) {
	$disconnect_next{ $server->{tag} } = 1;
    }
}

sub server_cap_end {
    my ($server) = @_;
    $server->disconnect
	if delete $disconnect_next{ $server->{tag} };
}

Irssi::settings_add_bool('server', 'sasl_disconnect_on_fail', 1);
Irssi::settings_add_bool('server', 'sasl_reconnect_on_fail', 0);
